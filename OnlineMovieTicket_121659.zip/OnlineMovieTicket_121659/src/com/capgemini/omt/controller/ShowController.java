package com.capgemini.omt.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.omt.dto.Shows;
import com.capgemini.omt.exceptions.ShowException;
import com.capgemini.omt.services.ShowService;
import com.capgemini.omt.services.ShowServiceImpl;

///showController
@WebServlet("*.do")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ShowService service;
	private RequestDispatcher dispatch;
	private String nextJsp;

	public ShowController() throws ShowException {
		service = new ShowServiceImpl();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		System.out.println(path);
		switch (path) {
		case "/show.do": {
			List<Shows> list = null;
			try {
				list = service.showAll();
				
			} catch (ShowException e) {
				System.out.println(e);
				System.out.println("Show method Failed");
			}
			request.setAttribute("data", list);
			nextJsp = "/showAll.jsp";
			break;
		}
		case "/book.do": {
			String data = request.getQueryString();
			String name = data.substring(3);

			Shows book;
			try {
				book = service.bookTicket(name);
				String sName = book.getShowName();
				int bookSeats = book.getAvSeats();
				float priceTicket = book.getPriceTicket();
				String sId = book.getShowId();
				
				request.setAttribute("id", sId);
				request.setAttribute("name", sName);
				request.setAttribute("seats", bookSeats);
				request.setAttribute("price", priceTicket);

				nextJsp = "bookNow.jsp";
			} catch (ShowException e) {
				System.out.println("Problem in bookTicket method");
			}

			break;
		}
		case "/booked.do": {
			String id = request.getParameter("showId");
			String sName = request.getParameter("showName");
			String cName = request.getParameter("cName");
			String mobileNo = request.getParameter("mobile");
			String number = request.getParameter("number");
			String price = request.getParameter("price");
			
			int noOfSeats = Integer.parseInt(number);
			float sPrice = Float.parseFloat(price);
			float totalPrice = sPrice * noOfSeats;

			request.setAttribute("sId", id);
			request.setAttribute("sname", sName);
			request.setAttribute("cname", cName);
			request.setAttribute("mobile", mobileNo);
			request.setAttribute("seats", noOfSeats);
			request.setAttribute("costPrice", totalPrice);
			try {
				boolean upadate = service.updateSeats(noOfSeats, id);
				
				if(upadate==true){
					nextJsp = "success.jsp";
				}else{
					nextJsp="error.jsp";
				}
			} catch (ShowException e) {
				System.out.println("Update method failed");
			}

			break;
		}

		}
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
	}

}
