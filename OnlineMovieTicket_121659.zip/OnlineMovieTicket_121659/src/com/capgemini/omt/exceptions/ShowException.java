package com.capgemini.omt.exceptions;

public class ShowException extends Exception {

	private static final long serialVersionUID = 2132977013332575172L;

	public ShowException() {

	}

	public ShowException(String message) {
		super(message);

	}

	public ShowException(Throwable cause) {
		super(cause);

	}

	public ShowException(String message, Throwable cause) {
		super(message, cause);

	}

	public ShowException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

}
